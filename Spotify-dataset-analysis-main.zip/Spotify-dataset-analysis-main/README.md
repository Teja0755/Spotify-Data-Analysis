# Spotify-dataset-analysis

For centuries, music has been a vital part of our daily existence. As time progresses, our means of accessing music have evolved. Presently, Spotify dominates the music streaming landscape, boasting over 100 million subscribers and a substantial 36% market share among online music platforms. This has prompted a deeper exploration of the Spotify song database to uncover intriguing patterns related to songs and their creators. 
The dataset comprises popular music tracks on Spotify spanning from 2010 to 2019, encompassing 603 entries across 14 columns.
